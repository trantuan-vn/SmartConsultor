// Requiring modules
	var TelegramBot = require('node-telegram-bot-api');
	var request = require('request');
	var xpath = require("xpath-html");
	var winax= require('winax'); 
	
// Token obtained from bot father
	var token="5669035075:AAF0azqsr9ParqL-7SbnC0yknN8nXCcTDgE";
	var chart_id="-1001776021646";
	var bot = new TelegramBot(token, { polling: true });
 
// Create a bot that uses 'polling' to
// fetch new updates
// bot.on("polling_error", (err) => console.log(err));
 
// The 'msg' is the received Message from user and
// 'match' is the result of execution above
// on the text content
//bot.onText(/\/Get (.+)/, function (msg, match) {
    // Getting the name of movie from the message
    // sent to bot
    //var symbol = match[1];
    //var chatId = msg.chat.id
	
	var query = 'https://mbs.com.vn/trung-tam-nghien-cuu/bao-cao-phan-tich/nghien-cuu-co-phieu/'
    
	request(query, function (error, response, body) {
         if (!error && response.statusCode == 200) {
			var xBody=xpath.fromPageSource(body);
			//console.log(body);
			
			//var nodeTitle = xBody.findElement("/html/body/main/section[2]/div/div[2]/div[2]/div/div[2]/div[1]/div[1]/a"); 
			var nodeTitle = xBody.findElements("//div[@class='card-news card-news-straight card-news-text mb-xsm']/div/a"); 
			if (nodeTitle.length>0){

				var currentDateTime = new Date();
				var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
				var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();
				
				
				bot.sendMessage(chart_id, "+ Tiêu đề: "+ nodeTitle[0].getText()
				+ "\n+ Ngày báo cáo: " + strDate.replaceAll("_","/")
				+ "\n+ Nguồn từ : Công ty chứng khoán MBS"
				+ "\n+ Nội dung: " + "https://mbs.com.vn" + nodeTitle[0].getAttribute("href"));
			}
			//console.log(query1);
			//console.log("\n"+nodeTitle[0].getText());
        }
    });


//})