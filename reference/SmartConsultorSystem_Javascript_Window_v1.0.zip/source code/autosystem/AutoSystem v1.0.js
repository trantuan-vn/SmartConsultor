// Requiring modules
var TelegramBot = require('node-telegram-bot-api');
var request = require('request');
var winax= require('winax'); 

// Token obtained from bot father
var token="5431606828:AAEDIenvthK1pkA0GBFhsLEp2sRgEiIjODY";
 
var bot = new TelegramBot(token, { polling: true });

// Create a bot that uses 'polling' to
// fetch new updates
bot.on("polling_error", (err) => console.log(err));
 
// The 'msg' is the received Message from user and
// 'match' is the result of execution above
// on the text content
bot.onText(/\/getimage (.+)/, function (msg, match) {
    // Getting the name of movie from the message
    // sent to bot
    var symbol = match[1];
    var chatId = msg.chat.id
	
	
	//console.log(symbol);
	var currentDateTime = new Date();
	var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
	var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

	AB = new ActiveXObject("Broker.Application");
	AW = AB.ActiveWindow;
	AB.ActiveDocument.Name = symbol;
	
	var fso = new ActiveXObject("Scripting.FileSystemObject"); 
	var filePath="D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images\\" + symbol + "_" + strDate + "_" + strTime + ".gif";
	if (!fso.FolderExists("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images")) {
		fso.CreateFolder("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images");
	}
	AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
	bot.sendPhoto(chatId, filePath, {caption: ""});
	
	
    /*
	//var query = 'http://api.openweathermap.org/data/2.5/weather?q=' + city + '&appid=YOUR_WEATHER_API_KEY'
 
    // Key obtained from openweathermap API
    request(query, function (error, response, body) {
 
        if (!error && response.statusCode == 200) {
 
            bot.sendMessage(chatId,
                '_Looking for details of_ ' + city
                + '...', { parse_mode: "Markdown" })
                .then(msg) {
                res = JSON.parse(body)
                var temp = Math.round((parseInt(
                    res.main.temp_min) - 273.15), 2)
 
                // Kelvin to celsius and then round
                // off and conversion to atm
                var pressure = Math.round(parseInt(
                        res.main.pressure) - 1013.15)
 
                var rise = new Date(parseInt(
                        res.sys.sunrise) * 1000);
 
                var set = new Date(parseInt(
                        res.sys.sunset) * 1000);
                // Unix time to IST time conversion
 
                bot.sendMessage(chatId, '**** '
                    + res.name + ' ****\nTemperature: '
                    + String(temp) + '°C\nHumidity: ' +
                    res.main.humidity + ' %\nWeather: '
                    + res.weather[0].description +
                    '\nPressure: ' + String(pressure)
                    + ' atm\nSunrise: ' +
                    rise.toLocaleTimeString() +
                    ' \nSunset: ' +
                    set.toLocaleTimeString() +
                    '\nCountry: ' + res.sys.country)
            }
 
            // Sending back the response from
            // the bot to user. The response
            // has many other details also
            // which can be used or sent as
            // per requirement
        }
    })
	*/
});
/*
bot.onText(/\/getranktop10 (.+)/, function (msg, match) {
    // Getting the name of movie from the message
    // sent to bot
    //var symbol = match[1];
    var chatId = msg.chat.id
	bot.sendMessage(chatId, "System: "+chatId);
	
	var AB, AA;
	AB = new ActiveXObject("Broker.Application");
	AA = AB.Analysis;
	AFL_Directory = "D:\\Amibroker\\AFL\\";                 // Location of AFL
	AFL_ExploreFileName = "9_realtime_break_sideway.afl";         // AFL program to get the data to be exported
	AFL_ExploreFile = AFL_Directory + AFL_ExploreFileName;   // Name of the above  program with it's path included
	
	var fso = new ActiveXObject("Scripting.FileSystemObject"); 
	Export_Directory = "D:\\Amibroker\\Daemons\\Server\\AutoSystem";              // Location where Exported data will be saved
	
	if (!fso.FolderExists(Export_Directory + "\\Results")) {
		fso.CreateFolder(Export_Directory + "\\Results");
	}

	AA.LoadFormula( AFL_ExploreFile );
	// AA.Filter(0,"favorite") = 1;   // Try this to load a long ticker which is favorites ^rut
	AA.ApplyTo = 2;                   // 0 = all stocks, 1 = current stock, 2 = use filter
	//AA.Filter(0,"watchlist") = 0;     // 0 = Include; "watchlist" number
	// Set Dates
	AA.RangeMode = 2;                    // 0 = all quotes, 1 = n last quotes, 2 = n last days, 3 = from-to date
	AA.RangeN = 1;
	//AA.RangeFromDate = "12/31/2002";
	//AA.RangeToDate = "12/31/2099";

	// ----------------------------------------------------------------------------
	// Run exploration, export exploration to csv file
	// ----------------------------------------------------------------------------
	AA.Explore();

	var currentDateTime = new Date();
	var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
	var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

	ExportFileName = "Result_" + strDate + "_" + strTime + ".csv"; // Name of export file
	
	ExportFile = Export_Directory + "\\Results\\" + ExportDateFileName; // Name of above export file with selected symbol in the date 
	
	AA.Export( ExportFile );	

	var s = fso.OpenTextFile(ExportFile, 1, true);
	s.ReadLine();
	var fields = s.ReadLine().split(',');
	var symbol=fields[0];cmd
	var top10=fields[0];
	for(var i=0;i<9;i++){
		fields = s.ReadLine().split(',');
		top10=top10 + ", " + fields[0];
	}

	s.close();
	
	bot.sendMessage(chatId, "10 chứng khoán mạnh nhất tại thời điểm " + strDate.replace("_","/").replace("_","/") + " " + strTime.replace("_",":").replace("_",":") + ": "+top10);
});
*/