const util=require('./src/common.js');

/*
	try {
		
	}
	catch (err){
		console.log(err.message);
	}
*/
