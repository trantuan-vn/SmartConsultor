const winax= require('winax'); 

const ProductionToken="5431606828:AAEDIenvthK1pkA0GBFhsLEp2sRgEiIjODY";
const PreProductionToken="5669035075:AAF0azqsr9ParqL-7SbnC0yknN8nXCcTDgE";
const ToSuccessGroupChartid="-1001776021646";

/*
	try {
		
	}
	catch (err){
		console.log(err.message);
	}
*/

function sleep(milliseconds) {
  try {
	  const date = Date.now();
	  let currentDate = null;
	  do {
		currentDate = Date.now();
	  } while (currentDate - date < milliseconds);
  }
  catch (err){
	  if (err) throw err;
  }
}

function exportResultOfExplore(exploreAFLPath, resultPath){
	try {
		AB = new winax.Object("Broker.Application");
		AA = AB.Analysis;
		AA.LoadFormula(exploreAFLPath);
		// AA.Filter(0,"favorite") = 1;   // Try this to load a long ticker which is favorites ^rut
		AA.ApplyTo = 2;                   // 0 = all stocks, 1 = current stock, 2 = use filter
		//AA.Filter(0,"watchlist") = 0;     // 0 = Include; "watchlist" number
		// Set Dates
		AA.RangeMode = 2;                    // 0 = all quotes, 1 = n last quotes, 2 = n last days, 3 = from-to date
		AA.RangeN = 1;
		//AA.RangeFromDate = "12/31/2002";
		//AA.RangeToDate = "12/31/2099";
		// ----------------------------------------------------------------------------
		// Run exploration, export exploration to csv file
		// ----------------------------------------------------------------------------
		AA.Explore();
		// export result
		AA.Export(resultPath);			
	}
	catch (err){
		if (err) throw err;
	}
}

function exportImage(symbol, resultPath){
	try {
		AB = new winax.Object("Broker.Application");
		AW = AB.ActiveWindow;
		AB.ActiveDocument.Name = symbol;
		AW.ExportImage( resultPath, 1280, 600 ); // 1280, 600 are pixel dimension
	}
	catch (err){
		if (err) throw err;
	}
}


function runShell(commandtoRun,textParms){
	try {
		var oShell = new winax.Object("Shell.Application");
		oShell.ShellExecute(commandtoRun, textParms, "", "open", "1");
	}
	catch (err){
		if (err) throw err;
	}
}

function sendMessage(token,charid,message){
	try {
		var commandtoRun = "curl.exe";
		var textParms = "-s -X POST \"https://api.telegram.org/bot" + token + "/sendMessage?chat_id=" + charid + "\" -d text=\"" + message + "\"";
		runShell(commandtoRun,textParms);
	}
	catch (err){
		if (err) throw err;
	}	
}

function sendPhoto(token,charid,filePath,cation){
	try {
		var commandtoRun = "curl.exe";
		var photoParms = "-s -X POST \"https://api.telegram.org/bot" + token + "/sendPhoto?chat_id=" + charid + "\" -F photo=\"@" + filePath +"\" -F caption=\"" + cation + "\"";		
		runShell(commandtoRun,photoParms);
	}
	catch (err){
		if (err) throw err;
	}	
}

function getDate(){
	try {
		var currentDateTime = new Date();
		var strDate=currentDateTime.getDate().toString() + "//" + (currentDateTime.getMonth() + 1).toString() + "//" + currentDateTime.getFullYear().toString();
		return strDate;
	}
	catch (err){
		if (err) throw err;
	}	
}

function getTime(){
	try {
		var currentDateTime = new Date();
		var strTime=currentDateTime.getHours().toString() + ":" + currentDateTime.getMinutes().toString() + ":" + currentDateTime.getSeconds().toString();
		return strTime;
	}
	catch (err){
		if (err) throw err;
	}	
}

