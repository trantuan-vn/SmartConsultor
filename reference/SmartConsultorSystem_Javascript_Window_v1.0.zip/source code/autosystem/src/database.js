const mysql = require('mysql');

function createConnection(ip,user,pass,dbName){
	var conn = mysql.createConnection({
	  host: ip,
	  user: user,
	  password: pass,
	  database: dbName
	});

	return conn;
}

function createConnectionPool(limited, ip,user,pass,dbName){
	var pool = mysql.createConnection({
	  connectionLimit: limited,
	  host: ip,
	  user: user,
	  password: pass,
	  database: dbName
	});

	return pool;
}


function executeSQLConn(conn,sql){
	var theResult;

	conn.connect(function(err) {
	  if (err) throw err;
	});	
	con.query(sql, function (err, result) {
		if (err) throw err;
		//console.log("Table created");
		theResult=result;
	});
	conn.end(function(err) {
	  if (err) throw err;
	});
	
	return theResult;
}

function executeSQLPool(pool,sql){
	var theResult;
	pool.getConnection(function(err, connection) {
		if (err) throw err; // not connected!

		// Use the connection
		connection.query(sql, function (error, results, fields) {
		// When done with the connection, release it.
		connection.release(function(err) {
			if (err) throw err;
		});
		// Handle error after the release.
		if (error) throw error;
		// Don't use the connection here, it has been returned to the pool.
		theResult=results;
	  });
	});	
	return theResult;
}






