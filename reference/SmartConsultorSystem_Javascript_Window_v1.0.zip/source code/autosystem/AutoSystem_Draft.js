//<script type="text/javascript" src="src/common.js"></script>
//<script type="text/javascript" src="src/ssi.js"></script>
/*
function sleep(milliseconds) {
  const date = Date.now();
  let currentDate = null;
  do {
    currentDate = Date.now();
  } while (currentDate - date < milliseconds);
}
*/
// Requiring modules
var TelegramBot = require('node-telegram-bot-api');
var request = require('request');
var xpath = require("xpath-html");
var winax= require('winax'); 
var axios = require('axios');
var fs = require('fs');

const util=require('./src/common.js');
const ssi=require('./src/ssi.js');

// Token obtained from bot father
var token="5431606828:AAEDIenvthK1pkA0GBFhsLEp2sRgEiIjODY";
 
var bot = new TelegramBot(token, { polling: true });
// Create a bot that uses 'polling' to
// fetch new updates
bot.on("polling_error", (err) => console.log(err));
 
bot.on('message', function(msg) {
    var text = msg.text;
    
	if (text){
		var chatId = msg.chat.id;
		
		var aText= text.trim().split(' ');
		if(aText.length>=2){
			if (aText[0]=='/image'){
				const funcExportFile = () {
					var symbol = aText[1];
					var filePath=".\\Tmp\\"+symbol+"_"+Date.now().toString()+ ".gif";
					util.exportImage(symbol,filePath);
					return Promise.resolve(filePath);
				}
				funcExportFile.then( (value) => {  
					bot.sendPhoto(chatId, value, {caption: ""});
				});
			}
		}
		
		if(aText.length==1){
			if (aText[0]=='/ranktop10'){
				var exportFile=".\\Tmp\\"+symbol+"_"+Date.now().toString()+".csv";
				const funcExportFile= () {
					var exploreAFLPath="./AFL/ranktop10.afl";
					util.exportResultOfExplore(exploreAFLPath,exportFile);	
					return Promise.resolve(filePath);
				}
				funcExportFile.then( (value) => {  
					var s = fso.OpenTextFile(exportFile, 1, true);
					s.ReadLine();
					var fields = s.ReadLine().split(',');
					var symbol=fields[0];
					var top10=fields[0]+ "\n";
					for(var i=0;i<9;i++){
						fields = s.ReadLine().split(',');
						top10=top10 + fields[0] + "\n";
					}
					s.close();
					bot.sendMessage(chatId, "10 chứng khoán mạnh nhất tại thời điểm " + strDate.replace("_","/").replace("_","/") + " " + strTime.replace("_",":").replace("_",":") + " là : \n" + top10);				
				});
			}
			
			if (aText[0]=='/recommendations'){
				// A. From SSI
				var symbolFromSSI;
				var query;
				
				try {
					var query = 'https://finfo-api.vndirect.com.vn/v4/news?q=newsType:company_report~locale:VN~newsSource:VNDIRECT&sort=newsDate:desc~newsTime:desc&size=1';

					var currentDateTime = new Date();
					var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
					var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

					var fso = new winax.Object("Scripting.FileSystemObject"); 
					var Export_Directory = "D:\\Amibroker\\Daemons\\Server\\AutoSystem\\"; 
					var filePath=Export_Directory + "Tmp\\" + strDate + "_" + strTime + "_FromVNDS.json";
					if (!fso.FolderExists(Export_Directory + "Tmp")) {
						fso.CreateFolder(Export_Directory + "Tmp");
					}

					var oShell = new winax.Object("Shell.Application");
					var commandtoRun = "curl.exe";
					var textParms = "\"https://finfo-api.vndirect.com.vn/v4/news?q=newsType:company_report~locale:VN~newsSource:VNDIRECT&sort=newsDate:desc~newsTime:desc&size=1\" -o \"" + filePath + "\"";
					oShell.ShellExecute(commandtoRun, textParms, "", "open", "1");

					sleep(500);
					var fileContents = fs.readFileSync(filePath, 'utf8');
					var res = JSON.parse(fileContents);

					var symbolFromSSI= res.data[0].tagCodes;
					var strNewsDate=res.data[0].newsDate;
					
					var strTitle= res.data[0].newsAbstract;
					
					var vLink=res.data[0].attachments[0].url;
					
					var AB = new winax.Object("Broker.Application");
					var AW = AB.ActiveWindow;
					AB.ActiveDocument.Name = symbolFromSSI;
					
					var fso = new winax.Object("Scripting.FileSystemObject"); 
					var Export_Directory = "D:\\Amibroker\\Logs\\Info\\"; 
					var filePath=Export_Directory + "Images\\" + symbolFromSSI + "_" + strDate.replaceAll("/","_") + "_FromVNDS.gif";
					if (!fso.FolderExists(Export_Directory + "Images")) {
						fso.CreateFolder(Export_Directory + "Images");
					}
					AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
					bot.sendPhoto(chatId, filePath, {caption: ""});
					bot.sendMessage(chatId, "+ Ngày giờ kết xuất ảnh: " + strDate.replaceAll("_","/") + " " + strTime.replaceAll("_",":")
					+ "\n+ Mã chứng khoán: "+ symbolFromSSI
					+ "\n+ Ngày báo cáo: " + strNewsDate
					+ "\n+ Nguồn từ : Công ty chứng khoán VNDS"
					+ "\n+ Nội dung tóm tắt : " + strTitle
					+ "\n+ Liên kết chi tiết : " + vLink);
				}
				catch(err) {
				  console.log(err.message);
				}
				
		
				sleep(500);
				query = 'https://www.ssi.com.vn/khach-hang-ca-nhan/bao-cao-cong-ty';
				// Key obtained from openweathermap API
				axios.get(query).then(resp => {
					try {
						var xBody=xpath.fromPageSource(resp.data);
							
						var nodeTitle = xBody.findElements("//a[@class='titlePost']"); 
						var strTitle = nodeTitle[0].getText();
						symbolFromSSI=strTitle.trim().substring(0, 3);
						
						var nodeDate = xBody.findElements("//div[@class='chart__content__item__time']/p/span"); 
						var strDate=nodeDate[0].getText(); 
						
						var nodeLink = xBody.findElements("//div[@class='chart__content__item__time']/a"); 
						var strLink=nodeLink[0].getAttribute("href"); 
						
						
						var nodeContent = xBody.findElements("//div[@class='chart__content__item__desc__info']/div/p/span/span/span/span/span"); 
						var strContent=nodeContent[0].getText();
						
						var fso = new winax.Object("Scripting.FileSystemObject"); 
						
						var currentDateTime = new Date();
						var strDate1=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
						var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

						var AB = new ActiveXObject("Broker.Application");
						var AW = AB.ActiveWindow;
						AB.ActiveDocument.Name = symbolFromSSI;
						
						var filePath="D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images\\" + symbolFromSSI + "_" + strDate.replaceAll("/","_") + "_FromSSI.gif";
						if (!fso.FolderExists("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images")) {
							fso.CreateFolder("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images");
						}
						AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
						
						bot.sendMessage(chatId, "+ Ngày giờ kết xuất ảnh: " + strDate1.replaceAll("_","/") + " " + strTime.replaceAll("_",":")
						+ "\n+ Mã chứng khoán: "+ symbolFromSSI
						+ "\n+ Ngày báo cáo: " + strDate
						+ "\n+ Nguồn từ : Công ty chứng khoán SSI"
						+ "\n+ Nội dung tóm tắt: " + strContent
						+ "\n+ Tải tệp tin : " + strLink);							
						bot.sendPhoto(chatId, filePath, {caption: ""});
					}
					catch(err) {
						console.log(err.message);
					}
				
				});
				sleep(500);
				query = 'https://mbs.com.vn/trung-tam-nghien-cuu/bao-cao-phan-tich/nghien-cuu-co-phieu/';
				axios.get(query).then(resp => {
					try {
						var xBody=xpath.fromPageSource(resp.data);
						var nodeTitle = xBody.findElements("//div[@class='card-news card-news-straight card-news-text mb-xsm']/div/a"); 
						if (nodeTitle.length>0){

							var currentDateTime = new Date();
							var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
							var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();
							
							
							bot.sendMessage(chatId, "+ Tiêu đề: "+ nodeTitle[0].getText()
							+ "\n+ Ngày báo cáo: " + strDate.replaceAll("_","/")
							+ "\n+ Nguồn từ : Công ty chứng khoán MBS"
							+ "\n+ Nội dung: " + "https://mbs.com.vn" + nodeTitle[0].getAttribute("href"));
						}
					}
					catch(err) {
						console.log(err.message);
					}
				});	
				sleep(500);
				query = 'https://www.bsc.com.vn/bao-cao-phan-tich/danh-muc-bao-cao/1';
				// Key obtained from openweathermap API
				axios.get(query).then(resp => {
					try {
						var xBody=xpath.fromPageSource(resp.data);
						
						var nodeTitle = xBody.findElements("//td[@class='link']/a"); 
						var strTitle = nodeTitle[0].getText();
						symbolFromSSI=strTitle.trim().substring(0, 3);
						
						var nodeDate = xBody.findElements("//td[@class='hidden-xs']"); 
						var strDate=nodeDate[0].getText(); 
						
						var nodeLink = xBody.findElements("//a[@class='btn btn-sm green']"); 
						var strLink=nodeLink[0].getAttribute("href"); 
						
						var fso = new winax.Object("Scripting.FileSystemObject"); 
						
						var currentDateTime = new Date();
						var strDate1=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
						var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

						var AB = new ActiveXObject("Broker.Application");
						var AW = AB.ActiveWindow;
						AB.ActiveDocument.Name = symbolFromSSI;
						
						var filePath="D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images\\" + symbolFromSSI + "_" + strDate.replaceAll("/","_") + "_FromBSC.gif";
						if (!fso.FolderExists("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images")) {
							fso.CreateFolder("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images");
						}
						AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
						
						bot.sendMessage(chatId, "+ Ngày giờ kết xuất ảnh: " + strDate1.replaceAll("_","/") + " " + strTime.replaceAll("_",":")
						+ "\n+ Mã chứng khoán: "+ symbolFromSSI
						+ "\n+ Ngày báo cáo: " + strDate
						+ "\n+ Nguồn từ : Công ty chứng khoán BSC"
						+ "\n+ Nội dung tóm tắt: " + strTitle
						+ "\n+ Tải tệp tin : https://www.bsc.com.vn/" + strLink);							
						
						bot.sendPhoto(chatId, filePath, {caption: ""});
					}
					catch(err) {
						console.log(err.message);
					}
				
				});				
/*						
				var query = 'https://www.ssi.com.vn/khach-hang-ca-nhan/bao-cao-cong-ty';
				request(query, function (error, response, body) {
					 if (!error && response.statusCode == 200) {
						var xBody=xpath.fromPageSource(body);
						
						var nodeTitle = xBody.findElements("//a[@class='titlePost']"); 
						var strTitle = nodeTitle[0].getText();
						symbolFromSSI=strTitle.trim().substring(0, 3);
						
						var nodeDate = xBody.findElements("//div[@class='chart__content__item__time']/p/span"); 
						var strDate=nodeDate[0].getText(); 
						
						
						var nodeContent = xBody.findElements("//div[@class='chart__content__item__desc__info']/div/p/span/span/span/span/span"); 
						var strContent=nodeContent[0].getText();
						
						var fso = new winax.Object("Scripting.FileSystemObject"); 
						
						var currentDateTime = new Date();
						var strDate1=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
						var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

						var AB = new ActiveXObject("Broker.Application");
						var AW = AB.ActiveWindow;
						AB.ActiveDocument.Name = symbolFromSSI;
						
						var filePath="D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images\\" + symbolFromSSI + "_" + strDate.replaceAll("/","_") + "_FromSSI.gif";
						if (!fso.FolderExists("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images")) {
							fso.CreateFolder("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images");
						}
						AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
						bot.sendPhoto(chatId, filePath, {caption: ""});
						bot.sendMessage(chatId, "+ Ngày giờ kết xuất ảnh: " + strDate1.replaceAll("_","/") + " " + strTime.replaceAll("_",":")
						+ "\n+ Mã chứng khoán: "+ symbolFromSSI
						+ "\n+ Ngày báo cáo: " + strDate
						+ "\n+ Nguồn từ : Công ty chứng khoán SSI"
							+ "\n+ Nội dung: " + strContent);						
					}
				});		
		
				// B. From VNDS
				query = 'https://finfo-api.vndirect.com.vn/v4/news?q=newsType:company_report~locale:VN~newsSource:VNDIRECT&sort=newsDate:desc~newsTime:desc&size=20';
				request(query, function (error, response, body) {
					 if (!error && response.statusCode == 200) {
						res = JSON.parse(body);

						var symbolFromSSI= res.data[0].tagCodes;
						var strDate=res.data[0].newsDate;
						
						var strTitle= res.data[0].newsAbstract;
						
						var vLink=res.data[0].attachments[0].url;
						
						
						var currentDateTime = new Date();
						var strDate1=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
						var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

						var AB = new winax.Object("Broker.Application");
						var AW = AB.ActiveWindow;
						AB.ActiveDocument.Name = symbolFromSSI;
						
						var fso = new winax.Object("Scripting.FileSystemObject"); 
						var Export_Directory = "D:\\Amibroker\\Logs\\Info\\"; 
						var filePath=Export_Directory + "Images\\" + symbolFromSSI + "_" + strDate.replaceAll("/","_") + "_FromVNDS.gif";
						if (!fso.FolderExists(Export_Directory + "Images")) {
							fso.CreateFolder(Export_Directory + "Images");
						}
						AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
						bot.sendPhoto(chatId, filePath, {caption: ""});
						bot.sendMessage(chatId, "+ Ngày giờ kết xuất ảnh: " + strDate1.replaceAll("_","/") + " " + strTime.replaceAll("_",":")
						+ "\n+ Mã chứng khoán: "+ symbolFromSSI
						+ "\n+ Ngày báo cáo: " + strDate
						+ "\n+ Nguồn từ : Công ty chứng khoán VNDS"
						+ "\n+ Nội dung tóm tắt : " + strTitle
						+ "\n+ Liên kết chi tiết : " + vLink);
					}
				});				
				// C. From MBS
				query = 'https://mbs.com.vn/trung-tam-nghien-cuu/bao-cao-phan-tich/nghien-cuu-co-phieu/'
				request(query, function (error, response, body) {
					 if (!error && response.statusCode == 200) {
						var xBody=xpath.fromPageSource(body);
						var nodeTitle = xBody.findElements("//div[@class='card-news card-news-straight card-news-text mb-xsm']/div/a"); 
						if (nodeTitle.length>0){

							var currentDateTime = new Date();
							var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
							var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();
							
							
							bot.sendMessage(chart_id, "+ Tiêu đề: "+ nodeTitle[0].getText()
							+ "\n+ Ngày báo cáo: " + strDate.replaceAll("_","/")
							+ "\n+ Nguồn từ : Công ty chứng khoán MBS"
							+ "\n+ Nội dung: " + "https://mbs.com.vn" + nodeTitle[0].getAttribute("href"));
						}
					}
				});	
*/				
				
			}
		}
	}		
});
