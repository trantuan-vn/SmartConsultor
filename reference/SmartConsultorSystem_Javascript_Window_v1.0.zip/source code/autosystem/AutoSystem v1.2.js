function sleep(milliseconds) {
  const date = Date.now();
  let currentDate = null;
  do {
    currentDate = Date.now();
  } while (currentDate - date < milliseconds);
}

// Requiring modules
var TelegramBot = require('node-telegram-bot-api');
var request = require('request');
var xpath = require("xpath-html");
var winax= require('winax'); 
var axios = require('axios');
var fs = require('fs');
// Token obtained from bot father
var token="5431606828:AAEDIenvthK1pkA0GBFhsLEp2sRgEiIjODY";
 
var bot = new TelegramBot(token, { polling: true });

// Create a bot that uses 'polling' to
// fetch new updates
bot.on("polling_error", (err) => console.log(err));
 
 bot.on('message', function(msg) {
    var text = msg.text;
    
	if (text){
		var chatId = msg.chat.id;
		
		var aText= text.trim().split(' ');
		if(aText.length>=2){
			if (aText[0]=='/image'){
				var symbol = aText[1];
				//console.log(symbol);
				var currentDateTime = new Date();
				var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
				var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

				AB = new ActiveXObject("Broker.Application");
				AW = AB.ActiveWindow;
				AB.ActiveDocument.Name = symbol;
				
				var fso = new ActiveXObject("Scripting.FileSystemObject"); 
				var filePath="D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images\\" + symbol + "_" + strDate + "_" + strTime + ".gif";
				if (!fso.FolderExists("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images")) {
					fso.CreateFolder("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images");
				}
				AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
				bot.sendPhoto(chatId, filePath, {caption: ""});				
			}
		}
		
		if(aText.length==1){
			if (aText[0]=='/ranktop10'){
				var AB, AA;
				AB = new ActiveXObject("Broker.Application");
				AA = AB.Analysis;
				AFL_Directory = "D:\\Amibroker\\AFL\\";                 // Location of AFL
				AFL_ExploreFileName = "9_realtime_break_sideway.afl";         // AFL program to get the data to be exported
				AFL_ExploreFile = AFL_Directory + AFL_ExploreFileName;   // Name of the above  program with it's path included
				
				var fso = new ActiveXObject("Scripting.FileSystemObject"); 
				Export_Directory = "D:\\Amibroker\\Daemons\\Server\\AutoSystem";              // Location where Exported data will be saved
				
				if (!fso.FolderExists(Export_Directory + "\\Results")) {
					fso.CreateFolder(Export_Directory + "\\Results");
				}

				AA.LoadFormula( AFL_ExploreFile );
				// AA.Filter(0,"favorite") = 1;   // Try this to load a long ticker which is favorites ^rut
				AA.ApplyTo = 2;                   // 0 = all stocks, 1 = current stock, 2 = use filter
				//AA.Filter(0,"watchlist") = 0;     // 0 = Include; "watchlist" number
				// Set Dates
				AA.RangeMode = 2;                    // 0 = all quotes, 1 = n last quotes, 2 = n last days, 3 = from-to date
				AA.RangeN = 1;
				//AA.RangeFromDate = "12/31/2002";
				//AA.RangeToDate = "12/31/2099";

				// ----------------------------------------------------------------------------
				// Run exploration, export exploration to csv file
				// ----------------------------------------------------------------------------
				AA.Explore();

				var currentDateTime = new Date();
				var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
				var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

				ExportFileName = "Result_" + strDate + "_" + strTime + ".csv"; // Name of export file
				
				ExportFile = Export_Directory + "\\Results\\" + ExportFileName; // Name of above export file with selected symbol in the date 
				
				AA.Export( ExportFile );	

				var s = fso.OpenTextFile(ExportFile, 1, true);
				s.ReadLine();
				var fields = s.ReadLine().split(',');
				var symbol=fields[0];
				var top10=fields[0]+ "\n";
				for(var i=0;i<9;i++){
					fields = s.ReadLine().split(',');
					top10=top10 + fields[0] + "\n";
				}

				s.close();
				
				bot.sendMessage(chatId, "10 chứng khoán mạnh nhất tại thời điểm " + strDate.replace("_","/").replace("_","/") + " " + strTime.replace("_",":").replace("_",":") + " là : \n" + top10);				
				
			}
			
			if (aText[0]=='/recommendations'){
				// A. From SSI
				var symbolFromSSI;
				var query;
				
				try {
					var query = 'https://finfo-api.vndirect.com.vn/v4/news?q=newsType:company_report~locale:VN~newsSource:VNDIRECT&sort=newsDate:desc~newsTime:desc&size=1';

					var currentDateTime = new Date();
					var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
					var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

					var fso = new winax.Object("Scripting.FileSystemObject"); 
					var Export_Directory = "D:\\Amibroker\\Daemons\\Server\\AutoSystem\\"; 
					var filePath=Export_Directory + "Tmp\\" + strDate + "_" + strTime + "_FromVNDS.json";
					if (!fso.FolderExists(Export_Directory + "Tmp")) {
						fso.CreateFolder(Export_Directory + "Tmp");
					}

					var oShell = new winax.Object("Shell.Application");
					var commandtoRun = "curl.exe";
					var textParms = "\"https://finfo-api.vndirect.com.vn/v4/news?q=newsType:company_report~locale:VN~newsSource:VNDIRECT&sort=newsDate:desc~newsTime:desc&size=1\" -o \"" + filePath + "\"";
					oShell.ShellExecute(commandtoRun, textParms, "", "open", "1");

					sleep(500);
					var fileContents = fs.readFileSync(filePath, 'utf8');
					var res = JSON.parse(fileContents);

					var symbolFromSSI= res.data[0].tagCodes;
					var strNewsDate=res.data[0].newsDate;
					
					var strTitle= res.data[0].newsAbstract;
					
					var vLink=res.data[0].attachments[0].url;
					
					var AB = new winax.Object("Broker.Application");
					var AW = AB.ActiveWindow;
					AB.ActiveDocument.Name = symbolFromSSI;
					
					var fso = new winax.Object("Scripting.FileSystemObject"); 
					var Export_Directory = "D:\\Amibroker\\Logs\\Info\\"; 
					var filePath=Export_Directory + "Images\\" + symbolFromSSI + "_" + strDate.replaceAll("/","_") + "_FromVNDS.gif";
					if (!fso.FolderExists(Export_Directory + "Images")) {
						fso.CreateFolder(Export_Directory + "Images");
					}
					AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
					bot.sendPhoto(chatId, filePath, {caption: ""});
					bot.sendMessage(chatId, "+ Ngày giờ kết xuất ảnh: " + strDate.replaceAll("_","/") + " " + strTime.replaceAll("_",":")
					+ "\n+ Mã chứng khoán: "+ symbolFromSSI
					+ "\n+ Ngày báo cáo: " + strNewsDate
					+ "\n+ Nguồn từ : Công ty chứng khoán VNDS"
					+ "\n+ Nội dung tóm tắt : " + strTitle
					+ "\n+ Liên kết chi tiết : " + vLink);
				}
				catch(err) {
				  console.log(err.message);
				}
				
		
				
				query = 'https://www.ssi.com.vn/khach-hang-ca-nhan/bao-cao-cong-ty';
				// Key obtained from openweathermap API
				axios.get(query).then(resp => {
					try {
						var xBody=xpath.fromPageSource(resp.data);
							
						var nodeTitle = xBody.findElements("//a[@class='titlePost']"); 
						var strTitle = nodeTitle[0].getText();
						symbolFromSSI=strTitle.trim().substring(0, 3);
						
						var nodeDate = xBody.findElements("//div[@class='chart__content__item__time']/p/span"); 
						var strDate=nodeDate[0].getText(); 
						
						
						var nodeContent = xBody.findElements("//div[@class='chart__content__item__desc__info']/div/p/span/span/span/span/span"); 
						var strContent=nodeContent[0].getText();
						
						var fso = new winax.Object("Scripting.FileSystemObject"); 
						
						var currentDateTime = new Date();
						var strDate1=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
						var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

						var AB = new ActiveXObject("Broker.Application");
						var AW = AB.ActiveWindow;
						AB.ActiveDocument.Name = symbolFromSSI;
						
						var filePath="D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images\\" + symbolFromSSI + "_" + strDate.replaceAll("/","_") + "_FromSSI.gif";
						if (!fso.FolderExists("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images")) {
							fso.CreateFolder("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images");
						}
						AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
						bot.sendPhoto(chatId, filePath, {caption: ""});
						bot.sendMessage(chatId, "+ Ngày giờ kết xuất ảnh: " + strDate1.replaceAll("_","/") + " " + strTime.replaceAll("_",":")
						+ "\n+ Mã chứng khoán: "+ symbolFromSSI
						+ "\n+ Ngày báo cáo: " + strDate
						+ "\n+ Nguồn từ : Công ty chứng khoán SSI"
							+ "\n+ Nội dung: " + strContent);							
					}
					catch(err) {
						console.log(err.message);
					}
				
				});
				
				query = 'https://mbs.com.vn/trung-tam-nghien-cuu/bao-cao-phan-tich/nghien-cuu-co-phieu/';
				axios.get(query).then(resp => {
					try {
						var xBody=xpath.fromPageSource(resp.data);
						var nodeTitle = xBody.findElements("//div[@class='card-news card-news-straight card-news-text mb-xsm']/div/a"); 
						if (nodeTitle.length>0){

							var currentDateTime = new Date();
							var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
							var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();
							
							
							bot.sendMessage(chatId, "+ Tiêu đề: "+ nodeTitle[0].getText()
							+ "\n+ Ngày báo cáo: " + strDate.replaceAll("_","/")
							+ "\n+ Nguồn từ : Công ty chứng khoán MBS"
							+ "\n+ Nội dung: " + "https://mbs.com.vn" + nodeTitle[0].getAttribute("href"));
						}
					}
					catch(err) {
						console.log(err.message);
					}
				});	
/*						
				var query = 'https://www.ssi.com.vn/khach-hang-ca-nhan/bao-cao-cong-ty';
				request(query, function (error, response, body) {
					 if (!error && response.statusCode == 200) {
						var xBody=xpath.fromPageSource(body);
						
						var nodeTitle = xBody.findElements("//a[@class='titlePost']"); 
						var strTitle = nodeTitle[0].getText();
						symbolFromSSI=strTitle.trim().substring(0, 3);
						
						var nodeDate = xBody.findElements("//div[@class='chart__content__item__time']/p/span"); 
						var strDate=nodeDate[0].getText(); 
						
						
						var nodeContent = xBody.findElements("//div[@class='chart__content__item__desc__info']/div/p/span/span/span/span/span"); 
						var strContent=nodeContent[0].getText();
						
						var fso = new winax.Object("Scripting.FileSystemObject"); 
						
						var currentDateTime = new Date();
						var strDate1=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
						var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

						var AB = new ActiveXObject("Broker.Application");
						var AW = AB.ActiveWindow;
						AB.ActiveDocument.Name = symbolFromSSI;
						
						var filePath="D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images\\" + symbolFromSSI + "_" + strDate.replaceAll("/","_") + "_FromSSI.gif";
						if (!fso.FolderExists("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images")) {
							fso.CreateFolder("D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images");
						}
						AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
						bot.sendPhoto(chatId, filePath, {caption: ""});
						bot.sendMessage(chatId, "+ Ngày giờ kết xuất ảnh: " + strDate1.replaceAll("_","/") + " " + strTime.replaceAll("_",":")
						+ "\n+ Mã chứng khoán: "+ symbolFromSSI
						+ "\n+ Ngày báo cáo: " + strDate
						+ "\n+ Nguồn từ : Công ty chứng khoán SSI"
							+ "\n+ Nội dung: " + strContent);						
					}
				});		
		
				// B. From VNDS
				query = 'https://finfo-api.vndirect.com.vn/v4/news?q=newsType:company_report~locale:VN~newsSource:VNDIRECT&sort=newsDate:desc~newsTime:desc&size=20';
				request(query, function (error, response, body) {
					 if (!error && response.statusCode == 200) {
						res = JSON.parse(body);

						var symbolFromSSI= res.data[0].tagCodes;
						var strDate=res.data[0].newsDate;
						
						var strTitle= res.data[0].newsAbstract;
						
						var vLink=res.data[0].attachments[0].url;
						
						
						var currentDateTime = new Date();
						var strDate1=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
						var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

						var AB = new winax.Object("Broker.Application");
						var AW = AB.ActiveWindow;
						AB.ActiveDocument.Name = symbolFromSSI;
						
						var fso = new winax.Object("Scripting.FileSystemObject"); 
						var Export_Directory = "D:\\Amibroker\\Logs\\Info\\"; 
						var filePath=Export_Directory + "Images\\" + symbolFromSSI + "_" + strDate.replaceAll("/","_") + "_FromVNDS.gif";
						if (!fso.FolderExists(Export_Directory + "Images")) {
							fso.CreateFolder(Export_Directory + "Images");
						}
						AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
						bot.sendPhoto(chatId, filePath, {caption: ""});
						bot.sendMessage(chatId, "+ Ngày giờ kết xuất ảnh: " + strDate1.replaceAll("_","/") + " " + strTime.replaceAll("_",":")
						+ "\n+ Mã chứng khoán: "+ symbolFromSSI
						+ "\n+ Ngày báo cáo: " + strDate
						+ "\n+ Nguồn từ : Công ty chứng khoán VNDS"
						+ "\n+ Nội dung tóm tắt : " + strTitle
						+ "\n+ Liên kết chi tiết : " + vLink);
					}
				});				
				// C. From MBS
				query = 'https://mbs.com.vn/trung-tam-nghien-cuu/bao-cao-phan-tich/nghien-cuu-co-phieu/'
				request(query, function (error, response, body) {
					 if (!error && response.statusCode == 200) {
						var xBody=xpath.fromPageSource(body);
						var nodeTitle = xBody.findElements("//div[@class='card-news card-news-straight card-news-text mb-xsm']/div/a"); 
						if (nodeTitle.length>0){

							var currentDateTime = new Date();
							var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
							var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();
							
							
							bot.sendMessage(chart_id, "+ Tiêu đề: "+ nodeTitle[0].getText()
							+ "\n+ Ngày báo cáo: " + strDate.replaceAll("_","/")
							+ "\n+ Nguồn từ : Công ty chứng khoán MBS"
							+ "\n+ Nội dung: " + "https://mbs.com.vn" + nodeTitle[0].getAttribute("href"));
						}
					}
				});	
*/				
				
			}
		}
	}		
});
