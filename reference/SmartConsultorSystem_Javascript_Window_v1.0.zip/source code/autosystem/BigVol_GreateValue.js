String.prototype.lpad = function(padString, length) {
    var str = this;
    while (str.length < length)
        str = padString + str;
    return str;
}

// Exploration_Example.js
//  This Java Script file should:
//  1. Load a Database
//  2. Run an exploration on an afl.
//  3. Exports the exploration to a csv file.
// ----------------------------------------------------------------------------
// Create AmiBroker object and get Analysis object
// ----------------------------------------------------------------------------
var AB, AA, i;
AB = new ActiveXObject("Broker.Application");
var fso = new ActiveXObject("Scripting.FileSystemObject"); 

AA = AB.Analysis;
// ----------------------------------------------------------------------------
// Load Database
// ----------------------------------------------------------------------------
//AB.LoadDatabase("C:\\Amibroker\\US-Stocks");
// ----------------------------------------------------------------------------
// Automatic Analysis Input and Export Information
// ----------------------------------------------------------------------------
AFL_Directory = "D:\\Amibroker\\AFL\\";                 // Location of AFL
AFL_ExploreFileName = "9_realtime_break_sideway.afl";         // AFL program to get the data to be exported
AFL_ExploreFile = AFL_Directory + AFL_ExploreFileName;   // Name of the above  program with it's path included

var currentDateTime = new Date();
var strDate1=currentDateTime.getDate().toString().lpad("0",2) + (currentDateTime.getMonth() + 1).toString().lpad("0",2) + currentDateTime.getFullYear().toString();

Export_Directory = "D:\\Amibroker\\Logs\\" + strDate1 + "\\";              // Location where Exported data will be saved

if (!fso.FolderExists("D:\\Amibroker\\Logs\\" + strDate1)) {
	fso.CreateFolder("D:\\Amibroker\\Logs\\" + strDate1);
}


var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();
ExportFileName = "Result_" + strDate + "_" + strTime + ".csv"; // Name of export file
ExportDateFileName = "Result_" + strDate + ".csv"; // Name of export date file

ExportFile = Export_Directory + "\\Results\\"+ ExportFileName;          // Name of above export file with its path included

if (!fso.FolderExists(Export_Directory + "\\Results")) {
	fso.CreateFolder(Export_Directory + "\\Results");
}
ExportDateFile = Export_Directory + ExportDateFileName; // Name of above export file with selected symbol in the date 

//Settings_Directory = "D:\\AmiBroker\\Settings\\";
//SettingsFileName = "SettingsBasic.ABS";
//SettingsFile = Settings_Directory + SettingsFileName;

// ----------------------------------------------------------------------------
// Load Reference Ticker into AmiBroker
// ----------------------------------------------------------------------------
//AB.ActiveDocument.Name = "RUT-I"; // Set RUT-I as reference ticker

// ----------------------------------------------------------------------------
// Automatic Analysis - Setup Exploration using info defined above
// ----------------------------------------------------------------------------
//AA.LoadSettings( SettingsFile );
AA.LoadFormula( AFL_ExploreFile );

// Use the following to tell Amibroker what to Include/Exclude and what dates to use
//
// "index", "favorite", "market", "group", "sector", "index", "watchlist"
// 0 = include; 1 = exclude
// 0 = all stocks, 1 = current stock, 2 = use filter
// 0 = all quotes, 1 = n last quotes, 2 = n last days, 3 = from-to date
//

// Set Filters
//AA.ClearFilters();

// AA.Filter(0,"favorite") = 1;   // Try this to load a long ticker which is favorites ^rut
AA.ApplyTo = 2;                   // 0 = all stocks, 1 = current stock, 2 = use filter
//AA.Filter(0,"watchlist") = 0;     // 0 = Include; "watchlist" number
// Set Dates
AA.RangeMode = 2;                    // 0 = all quotes, 1 = n last quotes, 2 = n last days, 3 = from-to date
AA.RangeN = 1;
//AA.RangeFromDate = "12/31/2002";
//AA.RangeToDate = "12/31/2099";

// ----------------------------------------------------------------------------
// Run exploration, export exploration to csv file
// ----------------------------------------------------------------------------
AA.Explore();
        
AA.Export( ExportFile );


var s = fso.OpenTextFile(ExportFile, 1, true);
s.ReadLine();
var fields = s.ReadLine().split(',');
var symbol=fields[0];
var top10=fields[0];
for(var i=0;i<9;i++){
	fields = s.ReadLine().split(',');
	top10=top10 + ", " + fields[0];
}

s.close();


var s1 = fso.OpenTextFile(ExportDateFile, 1, true);
var isExisted=false;
while (!s1.AtEndOfStream){
    symbol_1 = s1.ReadLine();
	if (symbol==symbol_1) {
		isExisted=true;
		break;
	}
}
s1.Close();

if (!isExisted)
{
	var s2 = fso.OpenTextFile(ExportDateFile, 8, true);
	s2.WriteLine(symbol);
	s2.close();
	
	AB = new ActiveXObject("Broker.Application");
	AW = AB.ActiveWindow;
	AB.ActiveDocument.Name = symbol;
	var filePath=Export_Directory + "Images\\" + symbol + ".gif";
	if (!fso.FolderExists(Export_Directory + "Images")) {
		fso.CreateFolder(Export_Directory + "Images");
	}
	AW.ExportImage( filePath, 1280, 600 ); // 640, 480 are pixel dimension

	var oShell = new ActiveXObject("Shell.Application");
	var token_id="5431606828:AAEDIenvthK1pkA0GBFhsLEp2sRgEiIjODY";
	var chart_id="-1001776021646";// ToSuccess
	//var chart_id="-1001812672451";//CK va Nhau
	var commandtoRun = "curl.exe";
	var photoParms = "-s -X POST \"https://api.telegram.org/bot" + token_id + "/sendPhoto?chat_id=" + chart_id + "\" -F photo=\"@" + filePath +"\" -F caption=\"\"";
	var textParms = "-s -X POST \"https://api.telegram.org/bot" + token_id + "/sendMessage?chat_id=" + chart_id 
	 + "\" -d text=\"-Ngày giờ kết xuất ảnh: " + strDate.replace("_","/").replace("_","/") + " " + strTime.replace("_",":").replace("_",":")
				+ "\n-Mã chứng khoán: "+ symbol
				+ "\n-Ngày báo cáo: " + strDate.replace("_","/").replace("_","/")
				+ "\n-Nguồn từ : AutomaticSystem"
				+ "\n-Nội dung: Mã chứng khoán xếp hạng cao nhất tại thời điểm kết xuất."
				+ "\n-Danh sách Top10 chứng khoán: "+ top10;
	
	oShell.ShellExecute(commandtoRun, textParms, "", "open", "1");
	oShell.ShellExecute(commandtoRun, photoParms, "", "open", "1");
}

// ----------------------------------------------------------------------------
// Save database (not really needed), Refresh database (also not really needed
// and close AA window when done.
// ----------------------------------------------------------------------------
//AB.SaveDatabase();
//AB.RefreshAll();

//AA.ShowWindow(0);                     // 0 = all stocks, 1 = current stock, 2 = use filter

// ----------------------------------------------------------------------------