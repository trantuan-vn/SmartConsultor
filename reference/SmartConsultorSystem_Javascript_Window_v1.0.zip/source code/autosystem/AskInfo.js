var TeleBot = require('telebot');
//var winax= require('winax'); 

const bot = new TeleBot({
    token: '5669035075:AAF0azqsr9ParqL-7SbnC0yknN8nXCcTDgE',
    usePlugins: ['askUser']
});

// On start command
bot.on('/image', msg => {

    const id = msg.from.id;

    // Ask user name
    return bot.sendMessage(id, 'Mã chứng khoán là: ', {ask: 'name'});

});

// Ask name event
bot.on('ask.name', msg => {

    const id = msg.from.id;

	var symbol = msg.text;
	//console.log(symbol);
	var currentDateTime = new Date();
	var strDate=currentDateTime.getDate().toString() + "_" + (currentDateTime.getMonth() + 1).toString() + "_" + currentDateTime.getFullYear().toString();
	var strTime=currentDateTime.getHours().toString() + "_" + currentDateTime.getMinutes().toString() + "_" + currentDateTime.getSeconds().toString();

	AB = new ActiveXObject("Broker.Application");
	AW = AB.ActiveWindow;
	AB.ActiveDocument.Name = symbol;
	var filePath="D:\\Amibroker\\Daemons\\Server\\AutoSystem\\Images\\" + symbol + "_" + strDate + "_" + strTime + ".gif";
	AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
		
    return bot.sendPhoto(id, filePath, {caption: ""});

});


bot.start();