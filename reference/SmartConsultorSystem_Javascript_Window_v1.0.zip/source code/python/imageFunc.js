function image(symbol,filePath) {
	AB = new ActiveXObject("Broker.Application");
	AW = AB.ActiveWindow;
	AB.ActiveDocument.Name = symbol;
	AW.ExportImage( filePath, 1280, 600 ); // 1280, 600 are pixel dimension
}

