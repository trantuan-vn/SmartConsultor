create user 'core' identified by 'telegram';
grant all privileges on *.* to core;
flush privileges;


